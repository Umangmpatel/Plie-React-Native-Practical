import React from 'react';
import Toast, { BaseToast, ErrorToast, ToastConfig } from 'react-native-toast-message';

const toastTextStyle = {
    fontSize: 13,
    fontWeight: '500' as const,
    textAlign: 'center' as const,
    flexShrink: 1,
};

const toastContainerStyle = { paddingHorizontal: 16 };

export const toastConfig: ToastConfig = {
    success: (props: any) => (
        <BaseToast
            {...props}
            style={{ borderLeftWidth: 0, borderTopWidth: 3, borderTopColor: '#4CAF50', minHeight: 48 }}
            contentContainerStyle={toastContainerStyle}
            text1Style={toastTextStyle}
            text1NumberOfLines={2}
            renderTrailingIcon={() => null}
        />
    ),
    error: (props: any) => (
        <ErrorToast
            {...props}
            style={{ borderLeftWidth: 0, borderTopWidth: 3, borderTopColor: '#E53935', minHeight: 48 }}
            contentContainerStyle={toastContainerStyle}
            text1Style={toastTextStyle}
            text1NumberOfLines={2}
            renderTrailingIcon={() => null}
        />
    ),
    info: (props: any) => (
        <BaseToast
            {...props}
            style={{ borderLeftWidth: 0, borderTopWidth: 3, borderTopColor: '#2196F3', minHeight: 48 }}
            contentContainerStyle={toastContainerStyle}
            text1Style={toastTextStyle}
            text1NumberOfLines={2}
            renderTrailingIcon={() => null}
        />
    ),
};

export const AlertDialog = (title: string) => {
    Toast.hide();
    Toast.show({
        type: 'error',
        text1: title,
        position: 'top',
        swipeable: false,
        visibilityTime: 3000,
    });
};

export const InfoDialog = (title: string) => {
    Toast.hide();
    Toast.show({
        type: 'info',
        text1: title,
        position: 'top',
        swipeable: false,
        visibilityTime: 3000,
    });
};

export const SuccessDialog = (title: string) => {
    Toast.hide();
    Toast.show({
        type: 'success',
        text1: title,
        position: 'top',
        swipeable: false,
        visibilityTime: 3000,
    });
};
