import { StyleSheet } from 'react-native';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import { COLORS } from '../../constants/Colors';
import { Fonts } from '../../constants/Fonts';

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.white,
    },
    header: {
        paddingHorizontal: scale(20),
        marginTop: verticalScale(10),
        marginBottom: verticalScale(10),
    },
    title: {
        color: COLORS.titleDark,
        fontSize: 24,
        fontFamily: Fonts.Satoshi.medium,
        marginBottom: verticalScale(4),
    },
    subtitle: {
        color: COLORS.subtitleDark,
        fontSize: 16,
        fontFamily: Fonts.Inter.regular,
    },
    contentContainer: {
        paddingHorizontal: scale(20),
        paddingBottom: verticalScale(40),
        marginTop: verticalScale(12),
        gap: moderateScale(12),
    },
});
