import React from 'react';
import { View, Text } from 'react-native';
import { STRINGS } from '../../../constants/Strings';
import { styles } from '../styles';

interface GreetingHeaderProps {
    userName?: string;
}

export const GreetingHeader: React.FC<GreetingHeaderProps> = ({ userName }) => {
    const greetingText = userName ? `${STRINGS.search.greetingTitle} ${userName}!` : STRINGS.search.greetingGuest;

    return (
        <View style={styles.greetingSection}>
            <Text style={styles.greetingTitle}>{greetingText}</Text>
            <Text style={styles.greetingSub}>{STRINGS.search.greetingSub}</Text>
        </View>
    );
};
