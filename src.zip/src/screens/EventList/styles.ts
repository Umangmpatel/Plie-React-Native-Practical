import { StyleSheet } from 'react-native';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import { COLORS } from '../../constants/Colors';
import { Fonts } from '../../constants/Fonts';

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.white,
    },
    content: {
        flex: 1,
    },
    contentContainer: {
        paddingBottom: verticalScale(40),
    },
    greetingSection: {
        paddingHorizontal: scale(20),
        justifyContent: 'center',
        marginTop: verticalScale(7),
        marginBottom: verticalScale(4),
    },
    greetingTitle: {
        color: COLORS.titleDark,
        fontSize: 24,
        fontFamily: Fonts.Satoshi.medium,
        marginBottom: verticalScale(5),
    },
    greetingSub: {
        color: COLORS.subtitleDark,
        fontSize: 16,
        fontFamily: Fonts.Inter.regular,
    },
    searchSection: {
        paddingHorizontal: scale(20),
    },
    eventsContainer: {
        paddingHorizontal: scale(20),
        marginTop: verticalScale(12),
        gap: moderateScale(12),
    },
});
