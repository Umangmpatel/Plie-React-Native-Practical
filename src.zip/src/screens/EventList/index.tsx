import React, { useEffect, useState, useMemo } from 'react';
import { View, Text, ScrollView, ActivityIndicator, RefreshControl } from 'react-native';
import { moderateScale } from 'react-native-size-matters';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { fetchEvents } from '../../store/slices/eventsSlice';
import { SearchIcon, CloseIcon } from '../../assets/icons';
import { EventCard, EmptyState, InputField } from '../../components/common';
import { useDebounce } from '../../hooks/useDebounce';
import { COLORS } from '../../constants/Colors';
import { GreetingHeader } from './components/GreetingHeader';
import { styles } from './styles';

export const EventListScreen = () => {
    const dispatch = useAppDispatch();
    const { events, loading } = useAppSelector(state => state.events);
    const { user } = useAppSelector(state => state.auth);

    const [searchQuery, setSearchQuery] = useState('');
    const [refreshing, setRefreshing] = useState(false);
    const debouncedQuery = useDebounce(searchQuery, 500);

    useEffect(() => {
        if (!events || events.length === 0) {
            dispatch(fetchEvents());
        }
    }, [dispatch, events?.length]);

    const onRefresh = React.useCallback(async () => {
        setRefreshing(true);
        setSearchQuery('');
        await dispatch(fetchEvents());
        setRefreshing(false);
    }, [dispatch]);

    const filteredEvents = useMemo(() => {
        if (!debouncedQuery.trim()) return events;
        const lowerCaseQuery = debouncedQuery.toLowerCase();
        return events?.filter(e => e.event_name?.toLowerCase().includes(lowerCaseQuery));
    }, [events, debouncedQuery]);

    const isEmpty = (!filteredEvents || filteredEvents.length === 0);

    return (
        <View style={styles.container}>
            <View style={{ backgroundColor: COLORS.white, zIndex: 1, paddingBottom: moderateScale(10) }}>
                <GreetingHeader userName={user?.usr_fname} />

                <View style={styles.searchSection}>
                    <InputField
                        leftIcon={<SearchIcon />}
                        rightIcon={searchQuery.length > 0 ? <CloseIcon /> : undefined}
                        onRightIconPress={() => setSearchQuery('')}
                        placeholder="Search events..."
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                    />
                </View>
            </View>

            <ScrollView
                style={styles.content}
                contentContainerStyle={[styles.contentContainer, ((loading && !refreshing) || isEmpty) && { flexGrow: 1 }]}
                showsVerticalScrollIndicator={false}
                refreshControl={
                    <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[COLORS.black]} tintColor={COLORS.black} />
                }
            >
                <View style={[styles.eventsContainer, ((loading && !refreshing) || isEmpty) && { flex: 1 }]}>
                    {loading && !refreshing ? (
                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: moderateScale(40) }}>
                            <ActivityIndicator size="large" color={COLORS.black} />
                            <Text style={{ marginTop: moderateScale(10), color: COLORS.black, fontSize: moderateScale(14) }}>Loading events...</Text>
                        </View>
                    ) : filteredEvents && filteredEvents.length > 0 ? (
                        filteredEvents.map((event, index) => {
                            const tags = event.danceStyles?.map((ds: any) => ds.ds_name) || [];
                            const location = `${event.city || ''}, ${event.country || ''}`;
                            const price = event.event_price_from === 0 && event.event_price_to === 0
                                ? 'Free'
                                : `€${event.event_price_from} - €${event.event_price_to}`;
                            return (
                                <EventCard
                                    eventId={event.event_date_id || event.event_id}
                                    key={event.event_date_id || event.event_id || index}
                                    imageSrc={event.event_profile_img}
                                    tags={tags}
                                    title={event.event_name}
                                    location={location}
                                    date={event.readable_from_date || ''}
                                    price={price}
                                />
                            );
                        })
                    ) : (
                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                            <EmptyState message="No events found." marginTop={0} />
                        </View>
                    )}
                </View>
            </ScrollView>
        </View>
    );
};
