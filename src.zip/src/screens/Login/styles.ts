import { StyleSheet } from 'react-native';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import { COLORS } from '../../constants/Colors';
import { Fonts } from '../../constants/Fonts';

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    background: {
        flex: 1,
        width: '100%',
        height: '100%',
    },
    topSpacer: {
        height: verticalScale(140),
    },
    headerContainer: {
        position: 'absolute',
        left: 0,
        right: 0,
        alignItems: 'center',
    },
    logoText: {
        color: COLORS.white,
        fontSize: 40,
        fontFamily: Fonts.HankenGrotesk.semiBold,
    },
    sheetContainer: {
        flex: 1,
        backgroundColor: COLORS.white,
        borderTopLeftRadius: moderateScale(30),
        borderTopRightRadius: moderateScale(30),
        paddingHorizontal: scale(24),
        paddingTop: verticalScale(28),
    },
    formSection: {
        width: '100%',
    },
    inputSpacing: {
        marginBottom: verticalScale(16),
    },
    forgotContainer: {
        alignSelf: 'flex-end',
        marginTop: verticalScale(4),
        marginBottom: verticalScale(20),
    },
    forgotText: {
        color: COLORS.subtitleDark,
        fontSize: 14,
        fontFamily: Fonts.Inter.regular,
    },
    signinButton: {
        alignSelf: 'flex-end',
        width: scale(100),
        height: verticalScale(35),
        marginTop: verticalScale(12),
        marginBottom: verticalScale(10),
    },
    signupContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop: verticalScale(16),
        marginBottom: verticalScale(20),
    },
    signupText: {
        color: COLORS.subtitleDark,
        fontSize: 14,
        fontFamily: Fonts.Inter.regular,
    },
    signupLink: {
        color: COLORS.black,
        fontSize: 14,
        fontFamily: Fonts.Inter.semiBold,
        textDecorationLine: 'underline',
    },
    dividerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: verticalScale(16),
    },
    dividerLine: {
        flex: 1,
        height: 1,
        backgroundColor: COLORS.tabBorderTop,
    },
    dividerText: {
        marginHorizontal: scale(12),
        color: COLORS.subtitleDark,
        fontSize: 12,
        fontFamily: Fonts.Inter.regular,
    },
    socialContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        gap: scale(16),
        marginTop: verticalScale(8),
    },
    socialIconBtn: {
        width: scale(44),
        height: scale(44),
        borderRadius: moderateScale(8),
        backgroundColor: COLORS.white,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: COLORS.tabBorderTop,
        elevation: 2,
        shadowColor: COLORS.black,
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
    },
    guestLink: {
        alignSelf: 'center',
        marginTop: verticalScale(20),
        marginBottom: verticalScale(16),
    },
    guestText: {
        color: COLORS.subtitleDark,
        fontSize: 14,
        fontFamily: Fonts.Inter.regular,
        textDecorationLine: 'underline',
    },
});
