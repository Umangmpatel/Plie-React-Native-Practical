import React from 'react';
import { View, TouchableOpacity } from 'react-native';
import { GoogleIcon, AppleIcon, FaceBookIcon } from '../../../assets/icons';
import { styles } from '../styles';

export const SocialLoginButtons: React.FC = () => {
    return (
        <View style={styles.socialContainer}>
            <TouchableOpacity style={styles.socialIconBtn} activeOpacity={0.8}>
                <GoogleIcon width={22} height={22} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialIconBtn} activeOpacity={0.8}>
                <AppleIcon width={22} height={22} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialIconBtn} activeOpacity={0.8}>
                <FaceBookIcon width={22} height={22} />
            </TouchableOpacity>
        </View>
    );
};
