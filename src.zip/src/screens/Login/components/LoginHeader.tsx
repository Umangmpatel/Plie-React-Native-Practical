import React from 'react';
import { View, Text } from 'react-native';
import { STRINGS } from '../../../constants/Strings';
import { styles } from '../styles';

interface LoginHeaderProps {
    topInset: number;
}

export const LoginHeader: React.FC<LoginHeaderProps> = ({ topInset }) => {
    return (
        <View style={[styles.headerContainer, { top: topInset + 30 }]}>
            <Text style={styles.logoText}>{STRINGS.appName}</Text>
        </View>
    );
};
