import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { InputField, Button } from '../../../components/common';
import { STRINGS } from '../../../constants/Strings';
import { styles } from '../styles';

interface LoginFormProps {
    email: string;
    setEmail: (email: string) => void;
    password: string;
    setPassword: (password: string) => void;
    emailError: string;
    setEmailError: (error: string) => void;
    passwordError: string;
    setPasswordError: (error: string) => void;
    handleLogin: () => void;
    loading: boolean;
}

export const LoginForm: React.FC<LoginFormProps> = ({
    email,
    setEmail,
    password,
    setPassword,
    emailError,
    setEmailError,
    passwordError,
    setPasswordError,
    handleLogin,
    loading,
}) => {
    return (
        <View style={styles.formSection}>
            <InputField
                label={STRINGS.login.emailLabel}
                placeholder={STRINGS.login.emailPlaceholder}
                value={email}
                onChangeText={(text) => {
                    setEmail(text);
                    if (emailError) setEmailError('');
                }}
                keyboardType="email-address"
                autoCapitalize="none"
                error={emailError}
                containerStyle={styles.inputSpacing}
            />

            <InputField
                label={STRINGS.login.passwordLabel}
                placeholder={STRINGS.login.passwordPlaceholder}
                value={password}
                onChangeText={(text) => {
                    setPassword(text);
                    if (passwordError) setPasswordError('');
                }}
                isPassword
                error={passwordError}
                containerStyle={styles.inputSpacing}
            />

            <TouchableOpacity style={styles.forgotContainer} activeOpacity={0.7}>
                <Text style={styles.forgotText}>{STRINGS.login.forgotPassword}</Text>
            </TouchableOpacity>

            <Button
                title={STRINGS.login.signIn}
                onPress={handleLogin}
                loading={loading}
                style={styles.signinButton}
            />
        </View>
    );
};
