import React, { useState } from 'react';
import { View, Text, ImageBackground, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';

import { LoginBgImage } from '../../assets/images';
import { LoginHeader } from './components/LoginHeader';
import { LoginForm } from './components/LoginForm';
import { SocialLoginButtons } from './components/SocialLoginButtons';

import { isValidEmail, isValidPassword } from '../../utils/validators';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { loginUser } from '../../store/slices/authSlice';
import { AlertDialog, SuccessDialog } from '../../utils/toast';
import { STRINGS } from '../../constants/Strings';
import { styles } from './styles';

export const LoginScreen = () => {
    const insets = useSafeAreaInsets();
    const dispatch = useAppDispatch();
    const { loading } = useAppSelector((state) => state.auth);

    const [email, setEmail] = useState('reactnative@plie.com');
    const [password, setPassword] = useState('password');

    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');

    const handleLogin = async () => {
        let isValid = true;

        if (!isValidEmail(email)) {
            setEmailError(STRINGS.login.validEmailError);
            isValid = false;
        } else {
            setEmailError('');
        }

        if (!isValidPassword(password)) {
            setPasswordError(STRINGS.login.validPasswordError);
            isValid = false;
        } else {
            setPasswordError('');
        }

        if (isValid) {
            try {
                const resultAction = await dispatch(loginUser({ email, password }));
                if (loginUser.fulfilled.match(resultAction)) {
                    SuccessDialog(STRINGS.login.loginSuccess);
                } else {
                    const errorMsg = (resultAction.payload as string) || STRINGS.login.loginError;
                    AlertDialog(errorMsg);
                }
            } catch (err: any) {
                AlertDialog(STRINGS.login.unexpectedError);
            }
        }
    };

    return (
        <View style={styles.container}>
            <ImageBackground source={LoginBgImage} style={styles.background} resizeMode="cover">
                <KeyboardAwareScrollView
                    style={{ flex: 1 }}
                    contentContainerStyle={{ flexGrow: 1 }}
                    bottomOffset={20}
                    keyboardShouldPersistTaps="handled"
                >
                    <View style={styles.topSpacer} />

                    <LoginHeader topInset={insets.top} />

                    <View style={styles.sheetContainer}>
                        <LoginForm
                            email={email}
                            setEmail={setEmail}
                            password={password}
                            setPassword={setPassword}
                            emailError={emailError}
                            setEmailError={setEmailError}
                            passwordError={passwordError}
                            setPasswordError={setPasswordError}
                            handleLogin={handleLogin}
                            loading={loading}
                        />

                        <View style={styles.signupContainer}>
                            <Text style={styles.signupText}>{STRINGS.login.notAMember} </Text>
                            <TouchableOpacity activeOpacity={0.7}>
                                <Text style={styles.signupLink}>{STRINGS.login.signUpHere}</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={styles.dividerContainer}>
                            <View style={styles.dividerLine} />
                            <Text style={styles.dividerText}>{STRINGS.login.orSignInWith}</Text>
                            <View style={styles.dividerLine} />
                        </View>

                        <SocialLoginButtons />

                        <TouchableOpacity style={styles.guestLink} activeOpacity={0.7}>
                            <Text style={styles.guestText}>{STRINGS.login.guest}</Text>
                        </TouchableOpacity>
                    </View>
                </KeyboardAwareScrollView>
            </ImageBackground>
        </View>
    );
};
