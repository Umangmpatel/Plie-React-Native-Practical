import React, { ReactNode } from 'react';
import { View, Text, TouchableOpacity, StyleProp, TextStyle } from 'react-native';
import { moderateScale } from 'react-native-size-matters';
import { RightArrowIcon } from '../../../assets/icons';
import { styles } from '../styles';

interface ProfileMenuItemProps {
    icon: ReactNode;
    title: string;
    onPress?: () => void;
    isLast?: boolean;
    isLogout?: boolean;
    textStyle?: StyleProp<TextStyle>;
}

export const ProfileMenuItem: React.FC<ProfileMenuItemProps> = ({
    icon,
    title,
    onPress,
    isLast = false,
    isLogout = false,
    textStyle,
}) => {
    return (
        <TouchableOpacity
            style={[styles.menuItem, isLast && styles.menuItemNoBorder]}
            activeOpacity={0.7}
            onPress={onPress}
        >
            <View style={styles.menuItemLeft}>
                <View style={styles.menuIconWrapper}>
                    {icon}
                </View>
                <Text style={[styles.menuItemText, isLogout && styles.menuItemTextLogout, textStyle]}>
                    {title}
                </Text>
            </View>
            {!isLogout && <RightArrowIcon width={moderateScale(12)} height={moderateScale(12)} />}
        </TouchableOpacity>
    );
};
