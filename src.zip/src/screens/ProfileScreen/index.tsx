import React from 'react';
import { View, Text, ScrollView, Alert } from 'react-native';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { logout } from '../../store/slices/authSlice';
import { SuccessDialog } from '../../utils/toast';
import { styles } from './styles';
import { moderateScale } from 'react-native-size-matters';
import { COLORS } from '../../constants/Colors';
import { STRINGS } from '../../constants/Strings';
import { ProfileMenuItem } from './components/ProfileMenuItem';
import {
    TicketIcon,
    PaymentIcon,
    NotoficationIcon,
    HelpSupportIcon,
    LogoutIcon,
    UnSelectedProfileIcon,
    EditIcon
} from '../../assets/icons';

export const ProfileScreen = () => {
    const dispatch = useAppDispatch();
    const { user } = useAppSelector((state) => state.auth);

    const displayName = user ? `${user.usr_fname || ''} ${user.usr_lname || ''}`.trim() : '';
    const displayEmail = user?.usr_email || '';

    const handleLogout = () => {
        Alert.alert(
            STRINGS.profile.logoutTitle,
            STRINGS.profile.logoutConfirm,
            [
                { text: STRINGS.profile.cancel, style: 'cancel' },
                {
                    text: STRINGS.profile.logout, style: 'destructive', onPress: () => {
                        SuccessDialog(STRINGS.profile.logoutSuccess);
                        dispatch(logout());
                    }
                }
            ]
        );
    };

    return (
        <View style={styles.container}>
            <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollViewContent}>
                <View style={styles.profileImageContainer}>
                    <UnSelectedProfileIcon width={moderateScale(48)} height={moderateScale(48)} />
                    <View style={styles.editIconBadge}>
                        <EditIcon width={moderateScale(26)} height={moderateScale(26)} />
                    </View>
                </View>

                {displayName ? <Text style={styles.nameText}>{displayName}</Text> : null}
                {displayEmail ? <Text style={styles.emailText}>{displayEmail}</Text> : null}

                <View style={styles.menuContainer}>
                    <ProfileMenuItem
                        icon={<TicketIcon width={moderateScale(20)} height={moderateScale(20)} />}
                        title={STRINGS.profile.myTickets}
                    />

                    <ProfileMenuItem
                        icon={<PaymentIcon width={moderateScale(20)} height={moderateScale(20)} />}
                        title={STRINGS.profile.paymentMethods}
                    />

                    <ProfileMenuItem
                        icon={<NotoficationIcon width={moderateScale(20)} height={moderateScale(20)} />}
                        title={STRINGS.profile.notificationSettings}
                    />

                    <ProfileMenuItem
                        icon={<HelpSupportIcon width={moderateScale(20)} height={moderateScale(20)} />}
                        title={STRINGS.profile.helpSupport}
                    />

                    <ProfileMenuItem
                        icon={<LogoutIcon width={moderateScale(20)} height={moderateScale(20)} color={COLORS.errorDeep} />}
                        title={STRINGS.profile.logout}
                        onPress={handleLogout}
                        isLogout
                        isLast
                    />
                </View>
            </ScrollView>
        </View>
    );
};
