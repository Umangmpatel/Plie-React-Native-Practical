import { StyleSheet } from 'react-native';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import { COLORS } from '../../constants/Colors';
import { Fonts } from '../../constants/Fonts';

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.surfaceWhite,
    },
    scrollView: {
        flex: 1,
    },
    scrollViewContent: {
        alignItems: 'center',
        paddingVertical: verticalScale(40),
        paddingHorizontal: scale(24),
    },
    profileImageContainer: {
        width: moderateScale(100),
        height: moderateScale(100),
        backgroundColor: '#F3F4F6',
        borderRadius: moderateScale(16),
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 2,
        borderColor: '#E5E7EB',
        position: 'relative',
        marginBottom: verticalScale(16),
    },
    editIconBadge: {
        position: 'absolute',
        bottom: -6,
        right: -6,
        borderWidth: 3,
        borderColor: COLORS.white,
        borderRadius: moderateScale(6),
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
    },
    editIconText: {
        color: COLORS.white,
        fontSize: moderateScale(12),
    },
    nameText: {
        fontSize: moderateScale(20),
        fontFamily: Fonts.Satoshi.bold,
        color: COLORS.black,
        marginBottom: verticalScale(4),
        textAlign: 'center',
    },
    emailText: {
        fontSize: moderateScale(13),
        fontFamily: Fonts.Inter.regular,
        color: COLORS.subtitleDark,
        marginBottom: verticalScale(32),
        textAlign: 'center',
    },
    menuContainer: {
        width: '100%',
        backgroundColor: COLORS.white,
        borderRadius: moderateScale(8),
        borderWidth: 1,
        borderColor: COLORS.tabBorderTop,
        overflow: 'hidden',
    },
    menuItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingVertical: verticalScale(20),
        paddingHorizontal: scale(20),
        borderBottomWidth: 1,
        borderBottomColor: COLORS.tabBorderTop,
    },
    menuItemNoBorder: {
        borderBottomWidth: 0,
    },
    menuItemLeft: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    menuIconWrapper: {
        width: moderateScale(24),
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: scale(16),
    },
    menuItemText: {
        fontSize: moderateScale(16),
        fontFamily: Fonts.Inter.regular,
        color: COLORS.titleDark,
    },
    menuItemTextLogout: {
        color: COLORS.errorDeep,
    },
});
