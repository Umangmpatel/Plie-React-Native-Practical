import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { LocationIcon, CalenderIcon } from '../../../assets/icons';
import { styles } from '../styles';

interface EventMetaInfoProps {
    location: string;
    date?: string;
    price: string;
    tags?: string[];
}

export const EventMetaInfo: React.FC<EventMetaInfoProps> = ({
    location,
    date,
    price,
    tags = [],
}) => {
    return (
        <View>
            {tags.length > 0 && (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tagsScroll}>
                    {tags.map((tag, idx) => (
                        <View key={idx} style={styles.tagBadge}>
                            <Text style={styles.tagText}>{tag}</Text>
                        </View>
                    ))}
                </ScrollView>
            )}

            <View style={styles.metaSection}>
                <View style={styles.metaRow}>
                    <View style={styles.metaIconBox}>
                        <LocationIcon width={16} height={18} />
                    </View>
                    <Text style={styles.metaText}>{location}</Text>
                </View>

                {date ? (
                    <View style={styles.metaRow}>
                        <View style={styles.metaIconBox}>
                            <CalenderIcon width={16} height={18} />
                        </View>
                        <Text style={styles.metaText}>{date}</Text>
                    </View>
                ) : null}
            </View>

            <View style={styles.priceBadge}>
                <Text style={styles.priceText}>{price}</Text>
            </View>
        </View>
    );
};
