import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { LeftArrowIcon } from '../../../assets/icons';
import { STRINGS } from '../../../constants/Strings';
import { styles } from '../styles';

interface EventNavHeaderProps {
    title?: string;
    onBack: () => void;
}

export const EventNavHeader: React.FC<EventNavHeaderProps> = ({ title, onBack }) => {
    return (
        <View style={styles.navHeader}>
            <TouchableOpacity style={styles.backButton} onPress={onBack} activeOpacity={0.7}>
                <LeftArrowIcon width={24} height={24} />
            </TouchableOpacity>
            <Text style={styles.navTitle} numberOfLines={1}>
                {title || STRINGS.eventDetails.title}
            </Text>
            <View style={styles.headerRightSpacer} />
        </View>
    );
};
