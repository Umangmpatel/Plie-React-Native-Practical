import React from 'react';
import { View, Image, TouchableOpacity } from 'react-native';
import { RedFavIcon, BlackUnfavIcon, ShareIcon } from '../../../assets/icons';
import { styles } from '../styles';

interface EventHeroHeaderProps {
    imageUri?: string;
    isFavorite: boolean;
    onToggleFavorite: () => void;
    onShare: () => void;
}

export const EventHeroHeader: React.FC<EventHeroHeaderProps> = ({
    imageUri,
    isFavorite,
    onToggleFavorite,
    onShare,
}) => {
    return (
        <View style={styles.heroContainer}>
            <Image
                source={imageUri ? { uri: imageUri } : require('../../../assets/images/loginBgImage.png')}
                style={styles.heroImage}
                resizeMode="cover"
            />

            <View style={styles.floatingOverlay}>
                <TouchableOpacity style={styles.iconCircle} activeOpacity={0.8} onPress={onShare}>
                    <ShareIcon width={18} height={18} />
                </TouchableOpacity>

                <TouchableOpacity style={styles.iconCircle} activeOpacity={0.8} onPress={onToggleFavorite}>
                    {isFavorite ? (
                        <RedFavIcon width={18} height={18} />
                    ) : (
                        <BlackUnfavIcon width={18} height={18} />
                    )}
                </TouchableOpacity>
            </View>
        </View>
    );
};
