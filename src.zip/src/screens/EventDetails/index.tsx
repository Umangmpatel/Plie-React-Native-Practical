import React from 'react';
import { View, Text, ScrollView, Share } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRoute, useNavigation } from '@react-navigation/native';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { toggleFavorite } from '../../store/slices/favoritesSlice';
import { Button } from '../../components/common';
import { EventNavHeader } from './components/EventNavHeader';
import { EventHeroHeader } from './components/EventHeroHeader';
import { EventMetaInfo } from './components/EventMetaInfo';
import { EventDetailsScreenRouteProp, EventDetailsScreenNavigationProp } from './types';
import { styles } from './styles';
import { STRINGS } from '../../constants/Strings';

export const EventDetailsScreen = () => {
    const route = useRoute<EventDetailsScreenRouteProp>();
    const navigation = useNavigation<EventDetailsScreenNavigationProp>();
    const dispatch = useAppDispatch();

    const { eventId } = route.params;
    const numericId = Number(eventId);

    const { events } = useAppSelector(state => state.events);
    const { favoriteIds } = useAppSelector(state => state.favorites);

    const event = events?.find(e => (e.event_date_id || e.event_id) === numericId);
    const isFavorite = favoriteIds.includes(numericId);

    const handleToggleFavorite = () => {
        dispatch(toggleFavorite(numericId));
    };

    const handleShare = async () => {
        try {
            await Share.share({
                message: `Check out this event: ${event?.event_name || 'Dance Event'}!`,
            });
        } catch (error) {
            console.log('Share error:', error);
        }
    };

    if (!event) {
        return (
            <SafeAreaView style={styles.container}>
                <EventNavHeader onBack={() => navigation.goBack()} />
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <Text style={styles.description}>{STRINGS.eventDetails.eventNotFound}</Text>
                </View>
            </SafeAreaView>
        );
    }

    const tags = event.danceStyles?.map((ds: any) => ds.ds_name) || [];
    const location = `${event.city || ''}, ${event.country || ''}`;
    const price = event.event_price_from === 0 && event.event_price_to === 0
        ? STRINGS.eventDetails.free
        : `€${event.event_price_from} - €${event.event_price_to}`;

    return (
        <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
            <EventNavHeader title={event.event_name} onBack={() => navigation.goBack()} />

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                <EventHeroHeader
                    imageUri={event.event_profile_img}
                    isFavorite={isFavorite}
                    onToggleFavorite={handleToggleFavorite}
                    onShare={handleShare}
                />

                <View style={styles.contentCard}>
                    <Text style={styles.title}>{event.event_name}</Text>

                    <EventMetaInfo
                        tags={tags}
                        location={location}
                        date={event.readable_from_date}
                        price={price}
                    />

                    {event.description ? (
                        <>
                            <Text style={styles.sectionTitle}>{STRINGS.eventDetails.aboutEvent}</Text>
                            <Text style={styles.description}>{event.description}</Text>
                        </>
                    ) : null}
                </View>
            </ScrollView>

            <View style={styles.bottomBar}>
                <Button title={STRINGS.eventDetails.bookNow} onPress={() => { }} />
            </View>
        </SafeAreaView>
    );
};
