import { StyleSheet } from 'react-native';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import { COLORS } from '../../constants/Colors';
import { Fonts } from '../../constants/Fonts';

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.white,
    },
    navHeader: {
        height: verticalScale(48),
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: scale(16),
        backgroundColor: COLORS.surfaceLight,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(0, 0, 0, 0.05)',
    },
    backButton: {
        padding: moderateScale(6),
        marginLeft: scale(-6),
    },
    navTitle: {
        fontSize: moderateScale(16),
        fontFamily: Fonts.Satoshi.bold,
        color: COLORS.black,
        textAlign: 'center',
        flex: 1,
    },
    headerRightSpacer: {
        width: moderateScale(32),
    },
    scrollContent: {
        paddingBottom: verticalScale(100),
    },
    heroContainer: {
        height: verticalScale(240),
        width: '100%',
        position: 'relative',
    },
    heroImage: {
        width: '100%',
        height: '100%',
    },
    floatingOverlay: {
        position: 'absolute',
        top: verticalScale(12),
        right: scale(16),
        flexDirection: 'row',
        gap: moderateScale(10),
        zIndex: 10,
    },
    iconCircle: {
        width: scale(36),
        height: scale(36),
        borderRadius: moderateScale(18),
        backgroundColor: 'rgba(255, 255, 255, 0.90)',
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: COLORS.black,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.15,
        shadowRadius: 3,
        elevation: 3,
    },
    contentCard: {
        paddingHorizontal: scale(20),
        paddingTop: verticalScale(16),
    },
    title: {
        fontSize: moderateScale(22),
        fontFamily: Fonts.Satoshi.bold,
        color: COLORS.titleDark,
        marginBottom: verticalScale(12),
    },
    tagsScroll: {
        marginBottom: verticalScale(16),
    },
    tagBadge: {
        paddingHorizontal: scale(10),
        paddingVertical: verticalScale(4),
        backgroundColor: 'rgba(249, 250, 251, 1)',
        borderRadius: moderateScale(9999),
        borderWidth: 1,
        borderColor: 'rgba(188, 202, 188, 0.3)',
        marginRight: scale(8),
    },
    tagText: {
        color: 'rgba(61, 65, 74, 1)',
        fontSize: moderateScale(12),
        fontFamily: Fonts.HankenGrotesk.regular,
    },
    metaSection: {
        gap: verticalScale(12),
        marginBottom: verticalScale(20),
    },
    metaRow: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    metaIconBox: {
        width: scale(28),
        alignItems: 'center',
    },
    metaText: {
        fontSize: moderateScale(14),
        fontFamily: Fonts.Inter.regular,
        color: COLORS.subtitleDark,
        marginLeft: scale(8),
    },
    priceBadge: {
        alignSelf: 'flex-start',
        backgroundColor: 'rgba(214, 0, 27, 0.08)',
        paddingHorizontal: scale(12),
        paddingVertical: verticalScale(6),
        borderRadius: moderateScale(6),
        marginBottom: verticalScale(20),
    },
    priceText: {
        fontSize: moderateScale(16),
        fontFamily: Fonts.HankenGrotesk.bold,
        color: COLORS.primary,
    },
    sectionTitle: {
        fontSize: moderateScale(16),
        fontFamily: Fonts.Satoshi.bold,
        color: COLORS.titleDark,
        marginBottom: verticalScale(8),
    },
    description: {
        fontSize: moderateScale(14),
        fontFamily: Fonts.Inter.regular,
        color: COLORS.subtitleDark,
        lineHeight: moderateScale(22),
    },
    bottomBar: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: COLORS.white,
        paddingHorizontal: scale(20),
        paddingVertical: verticalScale(12),
        borderTopWidth: 1,
        borderTopColor: 'rgba(0, 0, 0, 0.05)',
    },
});
