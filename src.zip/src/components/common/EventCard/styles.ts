import { StyleSheet } from 'react-native';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import { COLORS } from '../../../constants/Colors';
import { Fonts } from '../../../constants/Fonts';

export const styles = StyleSheet.create({
    cardContainer: {
        width: '100%',
        height: verticalScale(102),
        backgroundColor: COLORS.white,
        borderRadius: moderateScale(12),
        flexDirection: 'row',
        padding: moderateScale(8),
        elevation: 3,
        shadowColor: COLORS.black,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        alignItems: 'center',
        marginVertical: verticalScale(6),
        borderWidth: 1,
        borderColor: COLORS.cardBorder,
    },
    image: {
        width: scale(80),
        height: '100%',
        borderRadius: moderateScale(8),
        backgroundColor: '#E5E7EB',
    },
    contentContainer: {
        flex: 1,
        marginLeft: scale(10),
        justifyContent: 'space-between',
        height: '100%',
        paddingVertical: verticalScale(2),
    },
    topRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
    },
    tagsContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: scale(4),
        maxWidth: '85%',
    },
    tagBadge: {
        backgroundColor: 'rgba(249, 250, 251, 1)',
        paddingHorizontal: scale(6),
        paddingVertical: verticalScale(2),
        borderRadius: moderateScale(4),
        borderWidth: 1,
        borderColor: 'rgba(188, 202, 188, 0.3)',
    },
    tagText: {
        color: 'rgba(61, 65, 74, 1)',
        fontSize: moderateScale(10),
        fontFamily: Fonts.HankenGrotesk.regular,
    },
    title: {
        fontSize: moderateScale(14),
        fontFamily: Fonts.Satoshi.bold,
        color: COLORS.titleDark,
        marginVertical: verticalScale(2),
    },
    metaRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: verticalScale(1),
    },
    metaText: {
        fontSize: moderateScale(11),
        fontFamily: Fonts.Inter.regular,
        color: COLORS.subtitleDark,
        marginLeft: scale(4),
    },
    priceText: {
        fontSize: moderateScale(12),
        fontFamily: Fonts.HankenGrotesk.bold,
        color: COLORS.primary,
    },
    actionsRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: verticalScale(4),
    },
});
