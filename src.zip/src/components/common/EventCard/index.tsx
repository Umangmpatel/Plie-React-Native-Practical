import React from 'react';
import { View, Text, Image, TouchableOpacity, Share } from 'react-native';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { toggleFavorite } from '../../../store/slices/favoritesSlice';
import { LocationIcon, CalenderIcon, RedFavIcon, BlackUnfavIcon, ShareIcon } from '../../../assets/icons';
import { EventCardProps } from './types';
import { styles } from './styles';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../../navigation';

export const EventCard = ({ eventId, imageSrc, tags, title, location, date, price }: EventCardProps) => {
    const dispatch = useAppDispatch();
    const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
    const { favoriteIds } = useAppSelector(state => state.favorites);

    const isFavorite = favoriteIds.includes(eventId);

    const handleToggleFavorite = () => {
        dispatch(toggleFavorite(eventId));
    };

    const handleShare = async () => {
        try {
            await Share.share({
                message: `Check out this event: ${title || 'Dance Event'}!`,
            });
        } catch (error) {
            console.log('Share error:', error);
        }
    };

    const handleCardPress = () => {
        navigation.navigate('EventDetails', { eventId: String(eventId) });
    };

    return (
        <TouchableOpacity style={styles.cardContainer} activeOpacity={0.9} onPress={handleCardPress}>
            <Image
                source={imageSrc ? { uri: imageSrc } : require('../../../assets/images/loginBgImage.png')}
                style={styles.image}
                resizeMode="cover"
            />

            <View style={styles.contentContainer}>
                <View style={styles.topRow}>
                    <Text style={styles.title} numberOfLines={1}>
                        {title}
                    </Text>

                    <TouchableOpacity onPress={handleShare} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                        <ShareIcon width={moderateScale(14)} height={moderateScale(14)} />
                    </TouchableOpacity>
                </View>

                {tags && tags.length > 0 && (
                    <View style={styles.tagsContainer}>
                        {tags.slice(0, 2).map((tag, index) => (
                            <View key={index} style={styles.tagBadge}>
                                <Text style={styles.tagText}>{tag}</Text>
                            </View>
                        ))}
                    </View>
                )}

                <View style={styles.metaRow}>
                    <LocationIcon width={moderateScale(10)} height={moderateScale(12)} />
                    <Text style={styles.metaText} numberOfLines={1}>
                        {location}
                    </Text>
                </View>

                <View style={styles.actionsRow}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <CalenderIcon width={moderateScale(10)} height={moderateScale(12)} />
                        <Text style={[styles.metaText, { marginRight: moderateScale(8) }]}>{date}</Text>
                    </View>

                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: moderateScale(8) }}>
                        <Text style={styles.priceText}>{price}</Text>

                        <TouchableOpacity onPress={handleToggleFavorite} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                            {isFavorite ? (
                                <RedFavIcon width={moderateScale(16)} height={moderateScale(16)} />
                            ) : (
                                <BlackUnfavIcon width={moderateScale(16)} height={moderateScale(16)} />
                            )}
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    );
};
